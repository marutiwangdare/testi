<?php
//server 

define('DB_SERVER', 'localhost');
define('DB_USER', 'root');
define('DB_PASS', '');
define('DB_NAME', 'dwleaalz_learnwell_details');
$conn = mysqli_connect(DB_SERVER, DB_USER, DB_PASS, DB_NAME);

$url='http://localhost/learnwellportal/photo/testimonials/';
//local
/*
define('DB_SERVER', 'localhost'); 
define('DB_USER','root');
define('DB_PASS','');
 define('DB_NAME','dwleaalz_learwell_openings');
$conn=mysqli_connect(DB_SERVER,DB_USER,DB_PASS,DB_NAME);
*/
